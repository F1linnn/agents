#include "keynodes.hpp"

namespace PharmacySearchByCityAndRegionAgentModule
{

ScAddr Keynodes::action_pharmacyByCityAndRegionSearch;
ScAddr Keynodes::nrel_main_idtf;
ScAddr Keynodes::nrel_city;
ScAddr Keynodes::nrel_region;


}
