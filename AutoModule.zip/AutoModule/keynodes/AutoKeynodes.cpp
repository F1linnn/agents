/*
 * Author Ivan Teterski
 */

#include "sc-memory/sc_memory.hpp"

#include "AutoKeynodes.hpp"

namespace autoModule
{
ScAddr AutoKeynodes::nrel_site;
ScAddr AutoKeynodes::action_SiteSearch;
}  // namespace autoModule
