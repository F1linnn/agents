#include <memory>

#include "sc-memory/sc_memory.hpp"


#include "sc-memory/sc_event.hpp"




#define AutoKeynodes_hpp_17_init  bool _InitInternal() override \
{ \
    ScMemoryContext ctx(sc_access_lvl_make_min, "AutoKeynodes::_InitInternal"); \
    bool result = true; \
    return result; \
}


#define AutoKeynodes_hpp_17_initStatic static bool _InitStaticInternal()  \
{ \
    ScMemoryContext ctx(sc_access_lvl_make_min, "AutoKeynodes::_InitStaticInternal"); \
    bool result = true; \
	nrel_site = ctx.HelperResolveSystemIdtf("nrel_site", ScType::Node); result = result && nrel_site.IsValid(); \
	action_SiteSearch = ctx.HelperResolveSystemIdtf("action_SiteSearch", ScType::Node); result = result && action_SiteSearch.IsValid(); \
    return result; \
}


#define AutoKeynodes_hpp_17_decl 

#define AutoKeynodes_hpp_AutoKeynodes_impl 

#undef ScFileID
#define ScFileID AutoKeynodes_hpp

